package com.cybercrime.dto;

import com.cybercrime.model.Complaint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTOs — CO4: Clean REST API request/response bodies
 * Validation done here, not on entity layer
 */
public class Dtos {

    // ── AUTH ──

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class UserRegisterRequest {
        private String fullName;
        private String email;
        private String password;
        private String phoneNumber;
        private String address;
        private String city;
        private String state;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class LoginRequest {
        private String email;
        private String password;
        private String role; // USER | ADMIN | POLICE_OFFICER
    }

    @Data @NoArgsConstructor
    public static class AuthResponse {
        private String token;
        private String tokenType = "Bearer";
        private String role;
        private String email;
        private String fullName;
        private String redirectUrl;
        private String message;

        public AuthResponse(String token, String role, String email,
                            String fullName, String redirectUrl) {
            this.token = token;
            this.role = role;
            this.email = email;
            this.fullName = fullName;
            this.redirectUrl = redirectUrl;
        }
    }

    // ── COMPLAINT ──

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ComplaintRequest {
        private String title;
        private String description;
        private Complaint.CrimeType crimeType;
        private String incidentDate;
        private String incidentLocation;
        private String suspectDetails;
        private String websiteUrl;
        private Double amountLost;
        private Complaint.Priority priority;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ComplaintResponse {
        private Long id;
        private String complaintId;
        private String title;
        private String crimeType;
        private String status;
        private String priority;
        private String filedByName;
        private String filedByEmail;
        private String assignedOfficerName;
        private String assignedOfficerBadge;
        private String incidentDate;
        private String incidentLocation;
        private String description;
        private Double amountLost;
        private String investigationNotes;
        private String caseResolutionNotes;
        private int evidenceCount;
        private boolean solved;
        private String filedAt;
        private String lastUpdatedAt;
        private String resolvedAt;
        private String assignedOfficerEmail;
    }

    // ── OFFICER ──

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class OfficerCreateRequest {
        private String fullName;
        private String email;
        private String password;
        private String badgeNumber;
        private String rank;
        private String station;
        private String district;
        private String specialization;
        private String contactNumber;
    }

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class OfficerResponse {
        private Long id;
        private String fullName;
        private String email;
        private String badgeNumber;
        private String rank;
        private String station;
        private String district;
        private String specialization;
        private String contactNumber;
        private int activeCaseCount;
        private int resolvedCaseCount;
        private boolean active;
    }

    // ── ASSIGNMENT ──

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class AssignComplaintRequest {
        private Long officerId;
        private Complaint.Priority priority;
        private String notes;
    }

    // ── STATUS UPDATE ──

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class StatusUpdateRequest {
        private Complaint.ComplaintStatus newStatus;
        private String investigationNotes;
        private String caseResolutionNotes;
        private boolean solved;
    }

    // ── API WRAPPER ──

    @Data @NoArgsConstructor @AllArgsConstructor
    public static class ApiResponse<T> {
        private boolean success;
        private String message;
        private T data;

        public static <T> ApiResponse<T> success(String message, T data) {
            return new ApiResponse<>(true, message, data);
        }

        public static <T> ApiResponse<T> error(String message) {
            return new ApiResponse<>(false, message, null);
        }
    }
}
