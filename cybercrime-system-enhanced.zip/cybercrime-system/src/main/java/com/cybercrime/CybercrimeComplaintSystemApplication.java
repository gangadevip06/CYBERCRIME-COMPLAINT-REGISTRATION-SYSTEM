package com.cybercrime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * CybercrimeComplaintSystemApplication
 *
 * Entry point for the Cybercrime Complaint Registration System.
 * Built with Spring Boot, applying OOP, Collections, Multithreading,
 * REST APIs, and File I/O (CO1–CO5).
 *
 * @author Cybercrime System Team
 * @version 1.0.0
 */
@SpringBootApplication
@EnableAsync          // CO3: Enables async/multithreading for background tasks
@EnableScheduling     // CO3: Enables scheduled tasks (e.g., daily report generation)
public class CybercrimeComplaintSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(CybercrimeComplaintSystemApplication.class, args);
        System.out.println("""
            ╔══════════════════════════════════════════════════════════╗
            ║     CYBERCRIME COMPLAINT REGISTRATION SYSTEM v1.0       ║
            ║     Spring Boot | JWT | REST API | Role-Based Access    ║
            ║     Server: http://localhost:8080                        ║
            ║     H2 Console: http://localhost:8080/h2-console         ║
            ╚══════════════════════════════════════════════════════════╝
            """);
    }
}
