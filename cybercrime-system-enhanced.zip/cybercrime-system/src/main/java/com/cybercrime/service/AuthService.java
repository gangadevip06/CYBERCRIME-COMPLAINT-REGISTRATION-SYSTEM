package com.cybercrime.service;

import com.cybercrime.dto.Dtos.*;
import com.cybercrime.exception.CybercrimeException;
import com.cybercrime.model.*;
import com.cybercrime.repository.*;
import com.cybercrime.util.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * AuthService — CO5: Spring Boot Service
 * CO2: Exception handling for invalid credentials and duplicate accounts
 */
@Service
@Transactional
public class AuthService {

    private static final Logger log = LoggerFactory.getLogger(AuthService.class);

    @Autowired private UserRepository userRepository;
    @Autowired private AdminRepository adminRepository;
    @Autowired private PoliceOfficerRepository officerRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private JwtUtil jwtUtil;

    public AuthResponse registerUser(UserRegisterRequest req) {
        String email = req.getEmail().trim().toLowerCase();

        if (userRepository.existsByEmail(email))
            throw new CybercrimeException("Email already registered: " + email);

        User user = new User(
                req.getFullName().trim(),
                email,
                passwordEncoder.encode(req.getPassword()),
                req.getPhoneNumber(),
                req.getAddress()
        );
        user.setCity(req.getCity());
        user.setState(req.getState());
        userRepository.save(user);

        log.info("Registered user: {}", email);
        String token = jwtUtil.generateToken(email, "USER");
        return new AuthResponse(token, "USER", email, user.getFullName(), "/user/dashboard");
    }

    public AuthResponse login(LoginRequest req) {
        String email = req.getEmail().trim().toLowerCase();
        String role = req.getRole() != null ? req.getRole().toUpperCase() : "USER";

        return switch (role) {
            case "ADMIN"          -> loginAdmin(email, req.getPassword());
            case "POLICE_OFFICER" -> loginOfficer(email, req.getPassword());
            default               -> loginUser(email, req.getPassword());
        };
    }

    private AuthResponse loginUser(String email, String password) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new CybercrimeException("Invalid email or password"));
        if (!user.isActive())
            throw new CybercrimeException("Account is deactivated. Contact admin.");
        if (!passwordEncoder.matches(password, user.getPassword()))
            throw new CybercrimeException("Invalid email or password");

        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);
        log.info("User login: {}", email);
        return new AuthResponse(jwtUtil.generateToken(email, "USER"),
                "USER", email, user.getFullName(), "/user/dashboard");
    }

    private AuthResponse loginAdmin(String email, String password) {
        Admin admin = adminRepository.findByEmail(email)
                .orElseThrow(() -> new CybercrimeException("Invalid admin credentials"));
        if (!passwordEncoder.matches(password, admin.getPassword()))
            throw new CybercrimeException("Invalid admin credentials");

        admin.setLastLogin(LocalDateTime.now());
        adminRepository.save(admin);
        log.info("Admin login: {}", email);
        return new AuthResponse(jwtUtil.generateToken(email, "ADMIN"),
                "ADMIN", email, admin.getFullName(), "/admin/dashboard");
    }

    private AuthResponse loginOfficer(String email, String password) {
        PoliceOfficer officer = officerRepository.findByEmail(email)
                .orElseThrow(() -> new CybercrimeException("Invalid officer credentials"));
        if (!officer.isActive())
            throw new CybercrimeException("Officer account is inactive. Contact admin.");
        if (!passwordEncoder.matches(password, officer.getPassword()))
            throw new CybercrimeException("Invalid officer credentials");

        officer.setLastLogin(LocalDateTime.now());
        officerRepository.save(officer);
        log.info("Officer login: {}", email);
        return new AuthResponse(jwtUtil.generateToken(email, "POLICE_OFFICER"),
                "POLICE_OFFICER", email, officer.getFullName(), "/officer/dashboard");
    }
}
