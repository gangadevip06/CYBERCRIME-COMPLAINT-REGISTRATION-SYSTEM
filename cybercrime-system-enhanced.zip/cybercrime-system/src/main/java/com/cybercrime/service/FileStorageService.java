package com.cybercrime.service;

import com.cybercrime.exception.FileStorageException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import jakarta.annotation.PostConstruct;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * FileStorageService — CO2: File Handling using Java I/O Streams
 * Uses FileInputStream, FileOutputStream, BufferedReader for evidence file management.
 * CO3: @Async for multithreaded background file processing
 */
@Service
public class FileStorageService {

    private static final Logger logger = LoggerFactory.getLogger(FileStorageService.class);

    @Value("${app.upload.dir}")
    private String uploadDir;

    // CO3: Collection (HashMap) to track in-memory file metadata
    private final Map<String, String> fileMetaCache = Collections.synchronizedMap(new HashMap<>());

    // Allowed MIME types for security
    private static final Set<String> ALLOWED_TYPES = new HashSet<>(Arrays.asList(
            "image/jpeg", "image/png", "image/gif", "image/webp",
            "application/pdf",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "audio/mpeg", "audio/wav", "audio/ogg",
            "video/mp4", "video/avi", "video/quicktime",
            "text/plain", "application/zip"
    ));

    @PostConstruct
    public void init() {
        try {
            // CO2: File I/O — create storage directories
            Path uploadPath = Paths.get(uploadDir);
            Files.createDirectories(uploadPath);
            logger.info("Evidence upload directory initialized: {}", uploadPath.toAbsolutePath());

            // Write metadata log using FileWriter (CO2: FileWriter usage)
            writeSystemLog("FileStorageService initialized at " + new Date());
        } catch (IOException e) {
            throw new FileStorageException("Could not initialize file storage: " + e.getMessage());
        }
    }

    /**
     * Store an uploaded evidence file.
     * CO2: Uses Java I/O Streams (InputStream, FileOutputStream, BufferedOutputStream)
     * CO3: @Async — runs in separate thread (multithreading)
     */
    @Async("fileProcessingExecutor")
    public CompletableFuture<String> storeFileAsync(MultipartFile file, String complaintId) {
        try {
            String storedName = storeFile(file, complaintId);
            return CompletableFuture.completedFuture(storedName);
        } catch (IOException e) {
            return CompletableFuture.failedFuture(e);
        }
    }

    /**
     * Synchronous file storage for immediate use.
     * CO2: BufferedOutputStream wraps FileOutputStream for efficient I/O
     */
    public String storeFile(MultipartFile file, String complaintId) throws IOException {
        if (file.isEmpty()) {
            throw new FileStorageException("Cannot store empty file");
        }

        // Security: validate content type
        String contentType = file.getContentType();
        if (contentType == null || !ALLOWED_TYPES.contains(contentType)) {
            throw new FileStorageException("File type not allowed: " + contentType);
        }

        // CO2: String handling — generate unique stored file name
        String originalName = Objects.requireNonNull(file.getOriginalFilename())
                .replaceAll("[^a-zA-Z0-9._-]", "_");
        String extension = originalName.contains(".")
                ? originalName.substring(originalName.lastIndexOf("."))
                : "";
        String storedName = complaintId + "_" + UUID.randomUUID() + extension;

        // Create complaint-specific subdirectory
        Path complaintDir = Paths.get(uploadDir, complaintId);
        Files.createDirectories(complaintDir);

        Path targetPath = complaintDir.resolve(storedName);

        // CO2: I/O Streams — BufferedOutputStream for efficient writing
        try (InputStream inputStream = file.getInputStream();
             FileOutputStream fos = new FileOutputStream(targetPath.toFile());
             BufferedOutputStream bos = new BufferedOutputStream(fos)) {
            byte[] buffer = new byte[8192]; // 8KB buffer
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }
        }

        // Cache file path in memory (CO3: HashMap usage)
        fileMetaCache.put(storedName, targetPath.toString());

        logger.info("Stored evidence file: {} for complaint: {}", storedName, complaintId);
        writeSystemLog("FILE_STORED: " + storedName + " for complaint " + complaintId);

        return storedName;
    }

    /**
     * Load a file as bytes for download.
     * CO2: FileInputStream + BufferedInputStream
     */
    public byte[] loadFileAsBytes(String storedFileName, String complaintId) throws IOException {
        Path filePath = resolveFilePath(storedFileName, complaintId);
        if (!Files.exists(filePath)) {
            throw new FileStorageException("File not found: " + storedFileName);
        }

        // CO2: BufferedInputStream wraps FileInputStream for efficient reading
        try (FileInputStream fis = new FileInputStream(filePath.toFile());
             BufferedInputStream bis = new BufferedInputStream(fis);
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = bis.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }
            return baos.toByteArray();
        }
    }

    /**
     * Delete a file from storage.
     * CO2: File I/O — file deletion handling
     */
    public boolean deleteFile(String storedFileName, String complaintId) {
        try {
            Path filePath = resolveFilePath(storedFileName, complaintId);
            boolean deleted = Files.deleteIfExists(filePath);
            if (deleted) {
                fileMetaCache.remove(storedFileName);
                writeSystemLog("FILE_DELETED: " + storedFileName);
            }
            return deleted;
        } catch (IOException e) {
            logger.error("Error deleting file: {}", e.getMessage());
            return false;
        }
    }

    public Path resolveFilePath(String storedFileName, String complaintId) {
        return Paths.get(uploadDir, complaintId, storedFileName);
    }

    public String getFilePath(String storedFileName, String complaintId) {
        return resolveFilePath(storedFileName, complaintId).toString();
    }

    public boolean fileExists(String storedFileName, String complaintId) {
        return Files.exists(resolveFilePath(storedFileName, complaintId));
    }

    /**
     * CO2: FileWriter usage — writes system activity log
     */
    private void writeSystemLog(String message) {
        String logFile = uploadDir + "/system_activity.log";
        try (FileWriter fw = new FileWriter(logFile, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write("[" + new Date() + "] " + message);
            bw.newLine();
        } catch (IOException e) {
            logger.warn("Could not write to system log: {}", e.getMessage());
        }
    }

    /**
     * CO2: BufferedReader — reads system log for audit purposes
     */
    public List<String> readSystemLog(int maxLines) {
        List<String> lines = new ArrayList<>();
        String logFile = uploadDir + "/system_activity.log";
        File log = new File(logFile);
        if (!log.exists()) return lines;

        try (FileReader fr = new FileReader(log);
             BufferedReader br = new BufferedReader(fr)) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (IOException e) {
            logger.warn("Could not read system log: {}", e.getMessage());
        }

        // Return last N lines
        int size = lines.size();
        return size <= maxLines ? lines : lines.subList(size - maxLines, size);
    }
}
