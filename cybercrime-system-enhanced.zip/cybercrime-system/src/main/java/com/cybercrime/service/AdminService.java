package com.cybercrime.service;

import com.cybercrime.dto.Dtos.*;
import com.cybercrime.exception.CybercrimeException;
import com.cybercrime.model.PoliceOfficer;
import com.cybercrime.repository.PoliceOfficerRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * AdminService — CO5: Service layer for admin operations
 * Admin can add/remove officers, manage complaints
 */
@Service
@Transactional
public class AdminService {

    private static final Logger logger = LoggerFactory.getLogger(AdminService.class);

    @Autowired private PoliceOfficerRepository officerRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    public OfficerResponse addOfficer(OfficerCreateRequest request) {
        // CO2: Exception handling
        if (officerRepository.existsByEmail(request.getEmail())) {
            throw new CybercrimeException("Email already in use: " + request.getEmail());
        }
        if (officerRepository.existsByBadgeNumber(request.getBadgeNumber())) {
            throw new CybercrimeException("Badge number already registered: " + request.getBadgeNumber());
        }

        PoliceOfficer officer = new PoliceOfficer(
                request.getFullName(),
                request.getEmail(),
                passwordEncoder.encode(request.getPassword()),
                request.getBadgeNumber(),
                request.getRank(),
                request.getStation()
        );
        officer.setDistrict(request.getDistrict());
        officer.setSpecialization(request.getSpecialization());
        officer.setContactNumber(request.getContactNumber());

        officer = officerRepository.save(officer);
        logger.info("Admin added new officer: {} ({})", officer.getFullName(), officer.getBadgeNumber());
        return mapToResponse(officer);
    }

    public void removeOfficer(Long officerId) {
        PoliceOfficer officer = officerRepository.findById(officerId)
                .orElseThrow(() -> new CybercrimeException("Officer not found: " + officerId));

        // Soft delete — deactivate instead of hard delete
        officer.setActive(false);
        officerRepository.save(officer);
        logger.info("Officer deactivated: {} ({})", officer.getFullName(), officer.getBadgeNumber());
    }

    public List<OfficerResponse> getAllOfficers() {
        return officerRepository.findAll()
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    public List<OfficerResponse> getActiveOfficers() {
        return officerRepository.findByActiveTrue()
                .stream().map(this::mapToResponse).collect(Collectors.toList());
    }

    private OfficerResponse mapToResponse(PoliceOfficer o) {
        OfficerResponse r = new OfficerResponse();
        r.setId(o.getId());
        r.setFullName(o.getFullName());
        r.setEmail(o.getEmail());
        r.setBadgeNumber(o.getBadgeNumber());
        r.setRank(o.getRank());
        r.setStation(o.getStation());
        r.setDistrict(o.getDistrict());
        r.setSpecialization(o.getSpecialization());
        r.setContactNumber(o.getContactNumber());
        r.setActiveCaseCount(o.getActiveCaseCount());
        r.setResolvedCaseCount(o.getResolvedCaseCount());
        r.setActive(o.isActive());
        return r;
    }
}
