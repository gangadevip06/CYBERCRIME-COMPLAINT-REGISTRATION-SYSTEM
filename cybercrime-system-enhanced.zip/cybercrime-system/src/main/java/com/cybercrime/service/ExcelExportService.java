package com.cybercrime.service;

import com.cybercrime.model.Complaint;
import com.cybercrime.model.PoliceOfficer;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

/**
 * ExcelExportService — CO2: File I/O with Apache POI (XL format)
 * Exports Police Officer details and complaint reports to .xlsx files
 * Uses FileOutputStream, BufferedOutputStream for file writing
 */
@Service
@Transactional(readOnly = true)
public class ExcelExportService {

    private static final Logger logger = LoggerFactory.getLogger(ExcelExportService.class);
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

    @Value("${app.export.dir}")
    private String exportDir;

    /**
     * Export all police officers to Excel file (CO2: FileOutputStream)
     * Required: "police officer's details are stored in xl format"
     */
    public byte[] exportPoliceOfficersToExcel(List<PoliceOfficer> officers) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            XSSFSheet sheet = workbook.createSheet("Police Officers");

            // Styles
            XSSFCellStyle headerStyle = createHeaderStyle(workbook);
            XSSFCellStyle dataStyle = createDataStyle(workbook);
            XSSFCellStyle titleStyle = createTitleStyle(workbook);

            // Title row
            Row titleRow = sheet.createRow(0);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue("CYBERCRIME UNIT - POLICE OFFICER REGISTRY");
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 10));

            // Sub-header: export timestamp
            Row subRow = sheet.createRow(1);
            Cell subCell = subRow.createCell(0);
            subCell.setCellValue("Generated: " + LocalDateTime.now().format(FORMATTER));
            sheet.addMergedRegion(new CellRangeAddress(1, 1, 0, 10));

            // Column headers
            Row headerRow = sheet.createRow(3);
            String[] headers = {
                "S.No", "Badge Number", "Full Name", "Email", "Rank",
                "Station", "District", "Specialization", "Contact",
                "Active Cases", "Resolved Cases"
            };
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
                sheet.setColumnWidth(i, 4500);
            }

            // Data rows
            int rowNum = 4;
            for (int i = 0; i < officers.size(); i++) {
                PoliceOfficer o = officers.get(i);
                Row row = sheet.createRow(rowNum++);

                createCell(row, 0, String.valueOf(i + 1), dataStyle);
                createCell(row, 1, o.getBadgeNumber(), dataStyle);
                createCell(row, 2, o.getFullName(), dataStyle);
                createCell(row, 3, o.getEmail(), dataStyle);
                createCell(row, 4, o.getRank(), dataStyle);
                createCell(row, 5, o.getStation(), dataStyle);
                createCell(row, 6, o.getDistrict() != null ? o.getDistrict() : "-", dataStyle);
                createCell(row, 7, o.getSpecialization() != null ? o.getSpecialization() : "-", dataStyle);
                createCell(row, 8, o.getContactNumber() != null ? o.getContactNumber() : "-", dataStyle);
                createCell(row, 9, String.valueOf(o.getActiveCaseCount()), dataStyle);
                createCell(row, 10, String.valueOf(o.getResolvedCaseCount()), dataStyle);
            }

            // Summary row
            Row summaryRow = sheet.createRow(rowNum + 1);
            Cell summaryCell = summaryRow.createCell(0);
            summaryCell.setCellValue("Total Officers: " + officers.size());
            summaryCell.setCellStyle(headerStyle);

            workbook.write(baos);

            // Also save to disk (CO2: FileOutputStream)
            saveExcelToDisk(baos.toByteArray(), "police_officers_" +
                    LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmm")) + ".xlsx");

            logger.info("Exported {} police officers to Excel", officers.size());
            return baos.toByteArray();
        }
    }

    /**
     * Export complaint report to Excel
     */
    public byte[] exportComplaintsToExcel(List<Complaint> complaints, String reportTitle) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook();
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {

            XSSFSheet sheet = workbook.createSheet("Complaints");
            XSSFCellStyle headerStyle = createHeaderStyle(workbook);
            XSSFCellStyle dataStyle = createDataStyle(workbook);
            XSSFCellStyle titleStyle = createTitleStyle(workbook);

            // Title
            Row titleRow = sheet.createRow(0);
            Cell titleCell = titleRow.createCell(0);
            titleCell.setCellValue(reportTitle.toUpperCase());
            titleCell.setCellStyle(titleStyle);
            sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 9));

            Row subRow = sheet.createRow(1);
            subRow.createCell(0).setCellValue("Generated: " + LocalDateTime.now().format(FORMATTER));

            // Headers
            Row headerRow = sheet.createRow(3);
            String[] headers = {
                "S.No", "Complaint ID", "Title", "Crime Type", "Status",
                "Priority", "Filed By", "Assigned Officer", "Filed Date", "Solved"
            };
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
                sheet.setColumnWidth(i, i == 1 ? 6000 : i == 2 ? 8000 : 4500);
            }

            // Data
            int rowNum = 4;
            for (int i = 0; i < complaints.size(); i++) {
                Complaint c = complaints.get(i);
                Row row = sheet.createRow(rowNum++);
                createCell(row, 0, String.valueOf(i + 1), dataStyle);
                createCell(row, 1, c.getComplaintId() != null ? c.getComplaintId() : "-", dataStyle);
                createCell(row, 2, c.getTitle() != null ? c.getTitle() : "-", dataStyle);
                createCell(row, 3, c.getCrimeType() != null ? c.getCrimeType().getDisplayName() : "-", dataStyle);
                createCell(row, 4, c.getStatus() != null ? c.getStatus().getDisplayName() : "-", dataStyle);
                createCell(row, 5, c.getPriority() != null ? c.getPriority().name() : "-", dataStyle);
                String filedByName = "-";
                try { filedByName = c.getFiledBy() != null ? c.getFiledBy().getFullName() : "N/A"; } catch (Exception ignored) {}
                String officerName = "Unassigned";
                try { officerName = c.getAssignedOfficer() != null ? c.getAssignedOfficer().getFullName() : "Unassigned"; } catch (Exception ignored) {}
                createCell(row, 6, filedByName, dataStyle);
                createCell(row, 7, officerName, dataStyle);
                createCell(row, 8, c.getFiledAt() != null ? c.getFiledAt().format(FORMATTER) : "-", dataStyle);
                createCell(row, 9, c.isSolved() ? "Yes" : "No", dataStyle);
            }

            workbook.write(baos);
            return baos.toByteArray();
        }
    }

    // CO2: FileOutputStream — saves to disk
    private void saveExcelToDisk(byte[] data, String filename) {
        try {
            Files.createDirectories(Paths.get(exportDir));
            Path filePath = Paths.get(exportDir, filename);
            try (FileOutputStream fos = new FileOutputStream(filePath.toFile());
                 BufferedOutputStream bos = new BufferedOutputStream(fos)) {
                bos.write(data);
            }
            logger.info("Saved Excel file to disk: {}", filePath);
        } catch (IOException e) {
            logger.error("Failed to save Excel file: {}", e.getMessage());
        }
    }

    private void createCell(Row row, int col, String value, CellStyle style) {
        Cell cell = row.createCell(col);
        cell.setCellValue(value);
        cell.setCellStyle(style);
    }

    private XSSFCellStyle createHeaderStyle(XSSFWorkbook wb) {
        XSSFCellStyle style = wb.createCellStyle();
        XSSFFont font = wb.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.getIndex());
        style.setFont(font);
        style.setFillForegroundColor(new XSSFColor(new byte[]{(byte)0x1a, (byte)0x3a, (byte)0x5c}, null));
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setBorderBottom(BorderStyle.THIN);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }

    private XSSFCellStyle createDataStyle(XSSFWorkbook wb) {
        XSSFCellStyle style = wb.createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        style.setWrapText(false);
        return style;
    }

    private XSSFCellStyle createTitleStyle(XSSFWorkbook wb) {
        XSSFCellStyle style = wb.createCellStyle();
        XSSFFont font = wb.createFont();
        font.setBold(true);
        font.setFontHeightInPoints((short) 14);
        style.setFont(font);
        style.setAlignment(HorizontalAlignment.CENTER);
        return style;
    }
}
