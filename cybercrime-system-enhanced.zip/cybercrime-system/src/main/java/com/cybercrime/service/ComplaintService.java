package com.cybercrime.service;

import com.cybercrime.dto.Dtos.*;
import com.cybercrime.exception.CybercrimeException;
import com.cybercrime.model.*;
import com.cybercrime.repository.*;
import com.cybercrime.util.ComplaintIdGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * ComplaintService — CO5: Service Layer
 * CO3: ConcurrentHashMap (status cache), ArrayList (complaint lists)
 */
@Service
@Transactional
public class ComplaintService {

    private static final Logger log = LoggerFactory.getLogger(ComplaintService.class);

    @Autowired private ComplaintRepository complaintRepository;
    @Autowired private UserRepository userRepository;
    @Autowired private PoliceOfficerRepository officerRepository;
    @Autowired private EvidenceRepository evidenceRepository;
    @Autowired private FileStorageService fileStorageService;
    @Autowired private ComplaintIdGenerator idGenerator;

    // CO3: Thread-safe in-memory status cache
    private final ConcurrentHashMap<String, Complaint.ComplaintStatus> statusCache = new ConcurrentHashMap<>();

    // ── SUBMIT ──

    public ComplaintResponse submitComplaint(ComplaintRequest req, String userEmail,
                                              List<MultipartFile> files) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new CybercrimeException("User not found: " + userEmail));

        if (req.getTitle() == null || req.getTitle().isBlank())
            throw new CybercrimeException("Title is required");
        if (req.getCrimeType() == null)
            throw new CybercrimeException("Crime type is required");
        if (req.getDescription() == null || req.getDescription().isBlank())
            throw new CybercrimeException("Description is required");

        Complaint c = new Complaint();
        c.setComplaintId(idGenerator.generate());
        c.setTitle(req.getTitle().trim());
        c.setDescription(req.getDescription().trim());
        c.setCrimeType(req.getCrimeType());
        c.setStatus(Complaint.ComplaintStatus.PENDING);
        c.setPriority(req.getPriority() != null ? req.getPriority() : Complaint.Priority.MEDIUM);
        c.setIncidentDate(req.getIncidentDate());
        c.setIncidentLocation(req.getIncidentLocation());
        c.setSuspectDetails(req.getSuspectDetails());
        c.setWebsiteUrl(req.getWebsiteUrl());
        c.setAmountLost(req.getAmountLost());
        c.setFiledBy(user);

        c = complaintRepository.save(c);

        // CO2: File I/O — save evidence files
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                if (file != null && !file.isEmpty()) {
                    try {
                        String stored = fileStorageService.storeFile(file, c.getComplaintId());
                        Evidence ev = new Evidence();
                        ev.setOriginalFileName(file.getOriginalFilename() != null
                                ? file.getOriginalFilename() : "file");
                        ev.setStoredFileName(stored);
                        ev.setFilePath(fileStorageService.getFilePath(stored, c.getComplaintId()));
                        ev.setContentType(file.getContentType() != null
                                ? file.getContentType() : "application/octet-stream");
                        ev.setFileSizeBytes(file.getSize());
                        ev.setEvidenceType(detectType(file.getContentType()));
                        ev.setComplaint(c);
                        ev.setUploadedBy(user);
                        evidenceRepository.save(ev);
                    } catch (IOException e) {
                        log.error("Evidence save failed for {}: {}", c.getComplaintId(), e.getMessage());
                    }
                }
            }
        }

        statusCache.put(c.getComplaintId(), c.getStatus());
        log.info("Complaint filed: {} by {}", c.getComplaintId(), userEmail);
        return toResponse(c);
    }

    // ── TRACK ──

    @Transactional(readOnly = true)
    public ComplaintResponse trackComplaint(String complaintId, String userEmail) {
        Complaint c = complaintRepository.findByComplaintId(complaintId)
                .orElseThrow(() -> new CybercrimeException("Complaint not found: " + complaintId));
        if (c.getFiledBy() == null || !c.getFiledBy().getEmail().equals(userEmail))
            throw new CybercrimeException("This complaint does not belong to your account");
        return toResponse(c);
    }

    // ── USER COMPLAINTS ──

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getUserComplaints(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new CybercrimeException("User not found"));
        return complaintRepository.findByFiledBy(user)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    // ── ADMIN ──

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getAllComplaints() {
        return complaintRepository.findAll()
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> filterComplaintsByDays(int days) {
        LocalDateTime from = LocalDateTime.now().minusDays(days);
        return complaintRepository.findByFiledAtAfter(from)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getSolvedComplaints() {
        return complaintRepository.findBySolved(true)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getUnsolvedComplaints() {
        return complaintRepository.findBySolved(false)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public ComplaintResponse assignComplaint(String complaintId, AssignComplaintRequest req) {
        Complaint c = complaintRepository.findByComplaintId(complaintId)
                .orElseThrow(() -> new CybercrimeException("Complaint not found: " + complaintId));
        PoliceOfficer officer = officerRepository.findById(req.getOfficerId())
                .orElseThrow(() -> new CybercrimeException("Officer not found: " + req.getOfficerId()));

        c.setAssignedOfficer(officer);
        c.setStatus(Complaint.ComplaintStatus.UNDER_INVESTIGATION);
        c.setAssignedAt(LocalDateTime.now());
        if (req.getPriority() != null) c.setPriority(req.getPriority());
        if (req.getNotes() != null) c.setInvestigationNotes(req.getNotes());

        officer.incrementActiveCase();
        officerRepository.save(officer);
        c = complaintRepository.save(c);
        statusCache.put(c.getComplaintId(), c.getStatus());
        log.info("Complaint {} assigned to officer {}", complaintId, officer.getBadgeNumber());
        return toResponse(c);
    }

    // ── OFFICER ──

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getOfficerComplaints(String officerEmail) {
        PoliceOfficer officer = officerRepository.findByEmail(officerEmail)
                .orElseThrow(() -> new CybercrimeException("Officer not found"));
        return complaintRepository.findByAssignedOfficer(officer)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public ComplaintResponse updateComplaintStatus(String complaintId,
                                                    StatusUpdateRequest req,
                                                    String officerEmail) {
        Complaint c = complaintRepository.findByComplaintId(complaintId)
                .orElseThrow(() -> new CybercrimeException("Complaint not found: " + complaintId));
        PoliceOfficer officer = officerRepository.findByEmail(officerEmail)
                .orElseThrow(() -> new CybercrimeException("Officer not found"));

        if (req.getNewStatus() != null) c.setStatus(req.getNewStatus());

        // Enforce resolution notes when closing a case
        if (req.getNewStatus() == Complaint.ComplaintStatus.CLOSED) {
            if (req.getCaseResolutionNotes() == null || req.getCaseResolutionNotes().isBlank())
                throw new CybercrimeException("Case Resolution Details are required when closing a case.");
            c.setCaseResolutionNotes(req.getCaseResolutionNotes().trim());
            c.setSolved(true);
            c.setResolvedAt(LocalDateTime.now());
            officer.resolveCase();
            officerRepository.save(officer);
        }

        if (req.getInvestigationNotes() != null && !req.getInvestigationNotes().isBlank()) {
            String ts = LocalDateTime.now().toString().substring(0, 16);
            String note = "[" + ts + " | " + officer.getFullName() + "] " + req.getInvestigationNotes();
            String existing = c.getInvestigationNotes();
            c.setInvestigationNotes(existing != null ? existing + "\n" + note : note);
        }

        if (req.isSolved() || req.getNewStatus() == Complaint.ComplaintStatus.RESOLVED) {
            c.setSolved(true);
            c.setResolvedAt(LocalDateTime.now());
            officer.resolveCase();
            officerRepository.save(officer);
        }

        c = complaintRepository.save(c);
        statusCache.put(c.getComplaintId(), c.getStatus());
        return toResponse(c);
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> searchComplaints(String keyword) {
        if (keyword == null || keyword.isBlank()) return Collections.emptyList();
        return complaintRepository.searchComplaints(keyword.trim())
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getSolvedCaseHistory(String keyword, String crimeType) {
        List<Complaint> results;
        if (crimeType != null && !crimeType.isBlank()) {
            try {
                Complaint.CrimeType ct = Complaint.CrimeType.valueOf(crimeType);
                results = complaintRepository.findSolvedByCrimeType(ct);
            } catch (IllegalArgumentException e) {
                results = complaintRepository.findBySolved(true);
            }
        } else if (keyword != null && !keyword.isBlank()) {
            results = complaintRepository.searchSolvedCases(keyword.trim());
        } else {
            results = complaintRepository.findBySolved(true);
        }
        return results.stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getOfficerSolvedCases(String officerEmail) {
        PoliceOfficer officer = officerRepository.findByEmail(officerEmail)
                .orElseThrow(() -> new CybercrimeException("Officer not found"));
        return complaintRepository.findByAssignedOfficerAndSolved(officer, true)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<ComplaintResponse> getOfficerComplaintsByDateRange(String email, int days) {
        PoliceOfficer officer = officerRepository.findByEmail(email)
                .orElseThrow(() -> new CybercrimeException("Officer not found"));
        LocalDateTime from = LocalDateTime.now().minusDays(days);
        return complaintRepository.findByOfficerAndDateRange(officer, from)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<Evidence> getComplaintEvidence(String complaintId) {
        Complaint c = complaintRepository.findByComplaintId(complaintId)
                .orElseThrow(() -> new CybercrimeException("Complaint not found: " + complaintId));
        return evidenceRepository.findByComplaint(c);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getSystemStats() {
        // CO3: HashMap for stats aggregation
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalComplaints", complaintRepository.count());
        stats.put("solvedComplaints", complaintRepository.countBySolved(true));
        stats.put("unsolvedComplaints", complaintRepository.countBySolved(false));
        stats.put("pendingComplaints", complaintRepository.countByStatus(Complaint.ComplaintStatus.PENDING));
        stats.put("underInvestigation", complaintRepository.countByStatus(Complaint.ComplaintStatus.UNDER_INVESTIGATION));
        stats.put("totalOfficers", officerRepository.count());
        stats.put("activeOfficers", officerRepository.findByActiveTrue().size());

        // CO3: ArrayList for crime type breakdown
        List<Map<String, Object>> crimeBreakdown = new ArrayList<>();
        for (Complaint.CrimeType type : Complaint.CrimeType.values()) {
            long count = complaintRepository.countByCrimeType(type);
            if (count > 0) {
                Map<String, Object> entry = new HashMap<>();
                entry.put("type", type.getDisplayName());
                entry.put("count", count);
                crimeBreakdown.add(entry);
            }
        }
        stats.put("crimeBreakdown", crimeBreakdown);
        return stats;
    }

    // ── HELPERS ──

    private ComplaintResponse toResponse(Complaint c) {
        ComplaintResponse r = new ComplaintResponse();
        r.setId(c.getId());
        r.setComplaintId(c.getComplaintId());
        r.setTitle(c.getTitle());
        r.setCrimeType(c.getCrimeType() != null ? c.getCrimeType().getDisplayName() : "");
        r.setStatus(c.getStatus() != null ? c.getStatus().getDisplayName() : "");
        r.setPriority(c.getPriority() != null ? c.getPriority().name() : "MEDIUM");
        r.setDescription(c.getDescription());
        r.setIncidentDate(c.getIncidentDate());
        r.setIncidentLocation(c.getIncidentLocation());
        r.setAmountLost(c.getAmountLost());
        r.setInvestigationNotes(c.getInvestigationNotes());
        r.setCaseResolutionNotes(c.getCaseResolutionNotes());
        r.setSolved(c.isSolved());
        // Safe access of lazy-loaded fields (within transaction)
        try { if (c.getFiledBy() != null) {
            r.setFiledByName(c.getFiledBy().getFullName());
            r.setFiledByEmail(c.getFiledBy().getEmail());
        }} catch (Exception ignored) {}
        try { if (c.getAssignedOfficer() != null) {
            r.setAssignedOfficerName(c.getAssignedOfficer().getFullName());
            r.setAssignedOfficerBadge(c.getAssignedOfficer().getBadgeNumber());
            r.setAssignedOfficerEmail(c.getAssignedOfficer().getEmail());
        }} catch (Exception ignored) {}
        try { r.setEvidenceCount(c.getEvidenceList() != null ? c.getEvidenceList().size() : 0);
        } catch (Exception ignored) {}
        if (c.getFiledAt() != null) r.setFiledAt(c.getFiledAt().toString().substring(0, 16).replace("T", " "));
        if (c.getLastUpdatedAt() != null) r.setLastUpdatedAt(c.getLastUpdatedAt().toString().substring(0, 16).replace("T", " "));
        if (c.getResolvedAt() != null) r.setResolvedAt(c.getResolvedAt().toString().substring(0, 16).replace("T", " "));
        return r;
    }

    private Evidence.EvidenceType detectType(String ct) {
        if (ct == null) return Evidence.EvidenceType.OTHER;
        if (ct.startsWith("image/")) return Evidence.EvidenceType.SCREENSHOT;
        if (ct.startsWith("audio/")) return Evidence.EvidenceType.AUDIO;
        if (ct.startsWith("video/")) return Evidence.EvidenceType.VIDEO;
        if (ct.contains("pdf") || ct.contains("word") || ct.contains("document"))
            return Evidence.EvidenceType.DOCUMENT;
        if (ct.equals("text/plain")) return Evidence.EvidenceType.LOG_FILE;
        return Evidence.EvidenceType.OTHER;
    }
}
