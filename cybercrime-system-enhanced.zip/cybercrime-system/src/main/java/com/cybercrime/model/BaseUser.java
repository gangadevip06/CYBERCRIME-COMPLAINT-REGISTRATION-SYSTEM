package com.cybercrime.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * BaseUser — Abstract base class (CO1: Abstraction + Inheritance)
 * All user types inherit from this: User, Admin, PoliceOfficer
 */
@Getter
@Setter
@NoArgsConstructor
@MappedSuperclass
public abstract class BaseUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String fullName;

    @Column(nullable = false, unique = true)
    private String email;

    // No @NotBlank here — validation done at DTO layer, not entity layer
    @JsonIgnore
    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @Column(nullable = false)
    private boolean active = true;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column
    private LocalDateTime lastLogin;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    // CO1: Polymorphism — abstract method overridden by each subclass
    public abstract String getDashboardPath();

    public enum Role {
        USER, ADMIN, POLICE_OFFICER
    }
}
