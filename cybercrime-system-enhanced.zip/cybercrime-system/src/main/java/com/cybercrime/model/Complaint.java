package com.cybercrime.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Complaint entity — Core domain object (CO1: Encapsulation, OOP)
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "complaints")
public class Complaint {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, updatable = false)
    private String complaintId;  // Auto-generated: CC-YYYY-XXXXXXXX (CO2: String ops)

    @Column(nullable = false)
    private String title;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CrimeType crimeType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ComplaintStatus status = ComplaintStatus.PENDING;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priority priority = Priority.MEDIUM;

    @Column
    private String incidentDate;

    @Column
    private String incidentLocation;

    @Column
    private String suspectDetails;

    @Column
    private String websiteUrl;

    @Column
    private Double amountLost;

    @Column(columnDefinition = "TEXT")
    private String investigationNotes;

    @Column(columnDefinition = "TEXT")
    private String caseResolutionNotes;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "filed_by_user_id")
    private User filedBy;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "assigned_officer_id")
    private PoliceOfficer assignedOfficer;

    @JsonIgnore
    @OneToMany(mappedBy = "complaint", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<Evidence> evidenceList = new ArrayList<>();

    @Column(nullable = false, updatable = false)
    private LocalDateTime filedAt;

    @Column
    private LocalDateTime assignedAt;

    @Column
    private LocalDateTime resolvedAt;

    @Column
    private LocalDateTime lastUpdatedAt;

    @Column(nullable = false)
    private boolean solved = false;

    @PrePersist
    protected void onCreate() {
        filedAt = LocalDateTime.now();
        lastUpdatedAt = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        lastUpdatedAt = LocalDateTime.now();
    }

    // ── Enums ──

    public enum CrimeType {
        PHISHING("Phishing Attack"),
        MALWARE("Malware / Ransomware"),
        CYBER_FRAUD("Cyber Fraud / Online Scam"),
        IDENTITY_THEFT("Identity Theft"),
        CYBERBULLYING("Cyberbullying / Harassment"),
        HACKING("Unauthorized Hacking"),
        DATA_BREACH("Data Breach"),
        ONLINE_EXTORTION("Online Extortion"),
        CRYPTOCURRENCY_FRAUD("Cryptocurrency Fraud"),
        SOCIAL_MEDIA_CRIME("Social Media Crime"),
        EMAIL_FRAUD("Email Fraud"),
        OTHER("Other Cybercrime");

        private final String displayName;
        CrimeType(String d) { this.displayName = d; }
        public String getDisplayName() { return displayName; }
    }

    public enum ComplaintStatus {
        PENDING("Pending Review"),
        UNDER_INVESTIGATION("Under Investigation"),
        EVIDENCE_REVIEW("Evidence Review"),
        AWAITING_RESPONSE("Awaiting Response"),
        RESOLVED("Resolved"),
        CLOSED("Closed"),
        REJECTED("Rejected");

        private final String displayName;
        ComplaintStatus(String d) { this.displayName = d; }
        public String getDisplayName() { return displayName; }
    }

    public enum Priority { LOW, MEDIUM, HIGH, CRITICAL }
}
