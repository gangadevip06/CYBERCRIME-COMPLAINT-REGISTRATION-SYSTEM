package com.cybercrime.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * PoliceOfficer entity — CO1: Inheritance (extends BaseUser)
 * Details exportable to XL via ExcelExportService (CO2)
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@Entity
@Table(name = "police_officers")
public class PoliceOfficer extends BaseUser {

    @Column(nullable = false, unique = true)
    private String badgeNumber;

    @Column(nullable = false)
    private String rank;

    @Column(nullable = false)
    private String station;

    @Column
    private String district;

    @Column
    private String specialization;

    @Column
    private String contactNumber;

    @Column(nullable = false)
    private int activeCaseCount = 0;

    @Column(nullable = false)
    private int resolvedCaseCount = 0;

    @JsonIgnore
    @OneToMany(mappedBy = "assignedOfficer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Complaint> assignedComplaints = new ArrayList<>();

    public PoliceOfficer(String fullName, String email, String password,
                         String badgeNumber, String rank, String station) {
        setFullName(fullName);
        setEmail(email);
        setPassword(password);
        setRole(Role.POLICE_OFFICER);
        this.badgeNumber = badgeNumber;
        this.rank = rank;
        this.station = station;
    }

    @Override
    public String getDashboardPath() {
        return "/officer/dashboard";
    }

    public void incrementActiveCase() { this.activeCaseCount++; }

    public void resolveCase() {
        if (this.activeCaseCount > 0) this.activeCaseCount--;
        this.resolvedCaseCount++;
    }
}
