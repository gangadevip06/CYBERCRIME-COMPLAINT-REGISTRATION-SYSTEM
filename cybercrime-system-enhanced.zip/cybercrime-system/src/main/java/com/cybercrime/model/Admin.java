package com.cybercrime.model;

import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Admin entity — CO1: Inheritance (extends BaseUser)
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@Entity
@Table(name = "admins")
public class Admin extends BaseUser {

    @Column(nullable = false, unique = true)
    private String adminCode;

    @Column
    private String department;

    @Column
    private String designation;

    public Admin(String fullName, String email, String password, String adminCode) {
        setFullName(fullName);
        setEmail(email);
        setPassword(password);
        setRole(Role.ADMIN);
        this.adminCode = adminCode;
        this.designation = "System Administrator";
    }

    @Override
    public String getDashboardPath() {
        return "/admin/dashboard";
    }
}
