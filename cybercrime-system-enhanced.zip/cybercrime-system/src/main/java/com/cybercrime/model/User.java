package com.cybercrime.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * User entity — CO1: Inheritance (extends BaseUser), Encapsulation
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@Entity
@Table(name = "users")
public class User extends BaseUser {

    @Column
    private String phoneNumber;

    @Column
    private String address;

    @Column
    private String state;

    @Column
    private String city;

    @JsonIgnore
    @OneToMany(mappedBy = "filedBy", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Complaint> complaints = new ArrayList<>();

    public User(String fullName, String email, String password,
                String phoneNumber, String address) {
        setFullName(fullName);
        setEmail(email);
        setPassword(password);
        setRole(Role.USER);
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    @Override
    public String getDashboardPath() {
        return "/user/dashboard";
    }
}
