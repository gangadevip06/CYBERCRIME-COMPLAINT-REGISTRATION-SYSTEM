package com.cybercrime.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Evidence entity — CO2: File metadata stored in DB, actual files on disk
 */
@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "evidence")
public class Evidence {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String originalFileName;

    @Column(nullable = false, unique = true)
    private String storedFileName;

    @Column(nullable = false)
    private String filePath;

    @Column(nullable = false)
    private String contentType;

    @Column(nullable = false)
    private long fileSizeBytes;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EvidenceType evidenceType;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false, updatable = false)
    private LocalDateTime uploadedAt;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "complaint_id", nullable = false)
    private Complaint complaint;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "uploaded_by_user_id")
    private User uploadedBy;

    @PrePersist
    protected void onCreate() { uploadedAt = LocalDateTime.now(); }

    // CO2: Human-readable file size string
    public String getFileSizeFormatted() {
        if (fileSizeBytes < 1024) return fileSizeBytes + " B";
        else if (fileSizeBytes < 1048576) return String.format("%.1f KB", fileSizeBytes / 1024.0);
        else return String.format("%.1f MB", fileSizeBytes / 1048576.0);
    }

    public enum EvidenceType {
        SCREENSHOT("Screenshot / Image"),
        DOCUMENT("Document (PDF/DOC)"),
        AUDIO("Audio Recording"),
        VIDEO("Video Recording"),
        LOG_FILE("Log File"),
        OTHER("Other");

        private final String displayName;
        EvidenceType(String d) { this.displayName = d; }
        public String getDisplayName() { return displayName; }
    }
}
