package com.cybercrime.util;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * ComplaintIdGenerator — Auto-generates unique Complaint IDs
 * CO2: String Handling — constructs formatted IDs
 * CO3: Thread-safe with AtomicInteger for concurrent access
 * Format: CC-YYYY-XXXXXXXX (e.g., CC-2024-A1B2C3D4)
 */
@Component
public class ComplaintIdGenerator {

    // CO3: Thread-safe counter for uniqueness guarantee
    private static final AtomicInteger counter = new AtomicInteger(1000);

    /**
     * Generates a unique complaint ID.
     * CO2: String manipulation — substring, toUpperCase, format
     */
    public String generate() {
        int year = LocalDateTime.now().getYear();
        // Take first 8 chars of UUID, uppercase
        String uuidPart = UUID.randomUUID()
                .toString()
                .replace("-", "")
                .substring(0, 8)
                .toUpperCase();

        // Pad counter to ensure uniqueness even on same-millisecond requests
        int seq = counter.getAndIncrement();

        return String.format("CC-%d-%s%04d", year, uuidPart, seq % 10000);
    }

    /**
     * Validates complaint ID format (CO2: String operations)
     */
    public boolean isValidFormat(String complaintId) {
        if (complaintId == null || complaintId.isBlank()) return false;
        // Pattern: CC-YYYY-XXXXXXXX + counter
        return complaintId.matches("CC-\\d{4}-[A-Z0-9]{12}");
    }

    /**
     * Extract year from complaint ID (CO2: String parsing)
     */
    public int extractYear(String complaintId) {
        try {
            String[] parts = complaintId.split("-");
            return Integer.parseInt(parts[1]);
        } catch (Exception e) {
            return -1;
        }
    }
}
