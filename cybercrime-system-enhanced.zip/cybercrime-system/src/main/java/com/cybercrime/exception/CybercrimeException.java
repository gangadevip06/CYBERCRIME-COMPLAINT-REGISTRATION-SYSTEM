package com.cybercrime.exception;

public class CybercrimeException extends RuntimeException {
    public CybercrimeException(String message) {
        super(message);
    }
    public CybercrimeException(String message, Throwable cause) {
        super(message, cause);
    }
}
