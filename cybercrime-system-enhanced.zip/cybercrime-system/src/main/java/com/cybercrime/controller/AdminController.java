package com.cybercrime.controller;

import com.cybercrime.dto.Dtos.*;
import com.cybercrime.model.Evidence;
import com.cybercrime.model.PoliceOfficer;
import com.cybercrime.repository.ComplaintRepository;
import com.cybercrime.repository.PoliceOfficerRepository;
import com.cybercrime.service.AdminService;
import com.cybercrime.service.ComplaintService;
import com.cybercrime.service.ExcelExportService;
import com.cybercrime.service.FileStorageService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "*")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired private AdminService adminService;
    @Autowired private ComplaintService complaintService;
    @Autowired private ExcelExportService excelExportService;
    @Autowired private FileStorageService fileStorageService;
    @Autowired private PoliceOfficerRepository officerRepository;
    @Autowired private ComplaintRepository complaintRepository;

    @PostMapping("/officers")
    public ResponseEntity<ApiResponse<OfficerResponse>> addOfficer(
            @Valid @RequestBody OfficerCreateRequest request) {
        OfficerResponse response = adminService.addOfficer(request);
        return ResponseEntity.ok(ApiResponse.success("Officer added: " + response.getBadgeNumber(), response));
    }

    @DeleteMapping("/officers/{id}")
    public ResponseEntity<ApiResponse<Void>> removeOfficer(@PathVariable Long id) {
        adminService.removeOfficer(id);
        return ResponseEntity.ok(ApiResponse.success("Officer deactivated", null));
    }

    @GetMapping("/officers")
    public ResponseEntity<ApiResponse<List<OfficerResponse>>> getAllOfficers() {
        return ResponseEntity.ok(ApiResponse.success("Officers retrieved", adminService.getAllOfficers()));
    }

    @GetMapping("/officers/active")
    public ResponseEntity<ApiResponse<List<OfficerResponse>>> getActiveOfficers() {
        return ResponseEntity.ok(ApiResponse.success("Active officers", adminService.getActiveOfficers()));
    }

    @GetMapping("/officers/export")
    public ResponseEntity<byte[]> exportOfficersToExcel() throws IOException {
        List<PoliceOfficer> officers = officerRepository.findAll();
        byte[] data = excelExportService.exportPoliceOfficersToExcel(officers);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=police_officers.xlsx")
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(data);
    }

    @GetMapping("/complaints")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> getAllComplaints() {
        return ResponseEntity.ok(ApiResponse.success("All complaints", complaintService.getAllComplaints()));
    }

    @GetMapping("/complaints/filter")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> filterByDays(
            @RequestParam(defaultValue = "7") int days) {
        int safe = Math.min(Math.max(days, 1), 30);
        return ResponseEntity.ok(ApiResponse.success("Filtered complaints", complaintService.filterComplaintsByDays(safe)));
    }

    @GetMapping("/complaints/solved")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> getSolved() {
        return ResponseEntity.ok(ApiResponse.success("Solved complaints", complaintService.getSolvedComplaints()));
    }

    @GetMapping("/complaints/unsolved")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> getUnsolved() {
        return ResponseEntity.ok(ApiResponse.success("Unsolved complaints", complaintService.getUnsolvedComplaints()));
    }

    @PostMapping("/complaints/{complaintId}/assign")
    public ResponseEntity<ApiResponse<ComplaintResponse>> assignComplaint(
            @PathVariable String complaintId,
            @Valid @RequestBody AssignComplaintRequest request) {
        ComplaintResponse response = complaintService.assignComplaint(complaintId, request);
        return ResponseEntity.ok(ApiResponse.success("Assigned to " + response.getAssignedOfficerName(), response));
    }

    @GetMapping("/complaints/{complaintId}/evidence")
    public ResponseEntity<ApiResponse<List<Evidence>>> getEvidence(@PathVariable String complaintId) {
        return ResponseEntity.ok(ApiResponse.success("Evidence retrieved", complaintService.getComplaintEvidence(complaintId)));
    }

    @GetMapping("/stats")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getStats() {
        return ResponseEntity.ok(ApiResponse.success("Statistics", complaintService.getSystemStats()));
    }

    @GetMapping("/complaints/export")
    public ResponseEntity<byte[]> exportComplaints() throws IOException {
        byte[] data = excelExportService.exportComplaintsToExcel(complaintRepository.findAll(), "ALL COMPLAINTS REPORT");
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=complaints_report.xlsx")
                .contentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))
                .body(data);
    }

    @GetMapping("/logs")
    public ResponseEntity<ApiResponse<List<String>>> getLogs(@RequestParam(defaultValue = "50") int lines) {
        return ResponseEntity.ok(ApiResponse.success("Logs", fileStorageService.readSystemLog(lines)));
    }
}
