package com.cybercrime.controller;

import com.cybercrime.dto.Dtos.*;
import com.cybercrime.model.Evidence;
import com.cybercrime.service.ComplaintService;
import com.cybercrime.service.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

/**
 * OfficerController — CO4: REST API for Police Officer
 */
@RestController
@RequestMapping("/api/officer")
@CrossOrigin(origins = "*")
@PreAuthorize("hasRole('POLICE_OFFICER')")
public class OfficerController {

    @Autowired private ComplaintService complaintService;
    @Autowired private FileStorageService fileStorageService;

    @GetMapping("/complaints")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> getAssigned(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Cases retrieved",
                complaintService.getOfficerComplaints(auth.getName())));
    }

    @GetMapping("/complaints/search")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> search(@RequestParam String q) {
        return ResponseEntity.ok(ApiResponse.success("Search results",
                complaintService.searchComplaints(q)));
    }

    @GetMapping("/complaints/filter")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> filter(
            @RequestParam(defaultValue = "7") int days, Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Filtered cases",
                complaintService.getOfficerComplaintsByDateRange(auth.getName(), days)));
    }

    @PutMapping("/complaints/{complaintId}/status")
    public ResponseEntity<ApiResponse<ComplaintResponse>> updateStatus(
            @PathVariable String complaintId,
            @RequestBody StatusUpdateRequest request,
            Authentication auth) {
        ComplaintResponse response = complaintService.updateComplaintStatus(
                complaintId, request, auth.getName());
        return ResponseEntity.ok(ApiResponse.success("Status updated to: " + response.getStatus(), response));
    }

    @GetMapping("/complaints/{complaintId}/evidence")
    public ResponseEntity<ApiResponse<List<Evidence>>> getEvidence(@PathVariable String complaintId) {
        return ResponseEntity.ok(ApiResponse.success("Evidence retrieved",
                complaintService.getComplaintEvidence(complaintId)));
    }

    @GetMapping("/evidence/download/{storedName}")
    public ResponseEntity<byte[]> download(
            @PathVariable String storedName,
            @RequestParam String complaintId) throws IOException {
        byte[] data = fileStorageService.loadFileAsBytes(storedName, complaintId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + storedName + "\"")
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(data);
    }

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<String>> dashboard(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Officer dashboard", "Welcome Officer " + auth.getName()));
    }

    @GetMapping("/cases/solved")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> mySolvedCases(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Solved cases retrieved",
                complaintService.getOfficerSolvedCases(auth.getName())));
    }

    @GetMapping("/cases/knowledge-base")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> solvedKnowledgeBase(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String crimeType) {
        return ResponseEntity.ok(ApiResponse.success("Knowledge base retrieved",
                complaintService.getSolvedCaseHistory(keyword, crimeType)));
    }
}
