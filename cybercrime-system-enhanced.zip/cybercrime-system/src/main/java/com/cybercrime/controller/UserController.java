package com.cybercrime.controller;

import com.cybercrime.dto.Dtos.*;
import com.cybercrime.model.Evidence;
import com.cybercrime.service.ComplaintService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * UserController — CO4: REST API for citizen user operations
 */
@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "*")
@PreAuthorize("hasRole('USER')")
public class UserController {

    @Autowired
    private ComplaintService complaintService;

    /** Submit complaint with optional evidence files */
    @PostMapping(value = "/complaints", consumes = {"multipart/form-data"})
    public ResponseEntity<ApiResponse<ComplaintResponse>> submitComplaint(
            @RequestPart("complaint") ComplaintRequest request,
            @RequestPart(value = "evidence", required = false) List<MultipartFile> evidenceFiles,
            Authentication auth) {
        ComplaintResponse response = complaintService.submitComplaint(request, auth.getName(), evidenceFiles);
        return ResponseEntity.ok(ApiResponse.success(
                "Complaint filed! ID: " + response.getComplaintId(), response));
    }

    /** Get all complaints by this user */
    @GetMapping("/complaints")
    public ResponseEntity<ApiResponse<List<ComplaintResponse>>> getMyComplaints(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Complaints retrieved",
                complaintService.getUserComplaints(auth.getName())));
    }

    /** Track complaint by ID */
    @GetMapping("/complaints/track/{complaintId}")
    public ResponseEntity<ApiResponse<ComplaintResponse>> trackComplaint(
            @PathVariable String complaintId, Authentication auth) {
        ComplaintResponse response = complaintService.trackComplaint(complaintId, auth.getName());
        return ResponseEntity.ok(ApiResponse.success("Status retrieved", response));
    }

    @GetMapping("/dashboard")
    public ResponseEntity<ApiResponse<String>> dashboard(Authentication auth) {
        return ResponseEntity.ok(ApiResponse.success("Dashboard active", "Welcome " + auth.getName()));
    }
}
