package com.cybercrime.controller;

import com.cybercrime.dto.Dtos.*;
import com.cybercrime.exception.CybercrimeException;
import com.cybercrime.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * AuthController — CO4: REST API for authentication (register + login)
 */
@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<ApiResponse<AuthResponse>> register(@RequestBody UserRegisterRequest req) {
        if (req.getFullName() == null || req.getFullName().isBlank())
            return ResponseEntity.badRequest().body(ApiResponse.error("Full name is required"));
        if (req.getEmail() == null || req.getEmail().isBlank())
            return ResponseEntity.badRequest().body(ApiResponse.error("Email is required"));
        if (req.getPassword() == null || req.getPassword().length() < 6)
            return ResponseEntity.badRequest().body(ApiResponse.error("Password must be at least 6 characters"));

        AuthResponse response = authService.registerUser(req);
        response.setMessage("Registration successful! Welcome to the Cybercrime Complaint Portal.");
        return ResponseEntity.ok(ApiResponse.success("Registered successfully", response));
    }

    @PostMapping("/login")
    public ResponseEntity<ApiResponse<AuthResponse>> login(@RequestBody LoginRequest req) {
        if (req.getEmail() == null || req.getEmail().isBlank())
            return ResponseEntity.badRequest().body(ApiResponse.error("Email is required"));
        if (req.getPassword() == null || req.getPassword().isBlank())
            return ResponseEntity.badRequest().body(ApiResponse.error("Password is required"));

        AuthResponse response = authService.login(req);
        response.setMessage("Login successful.");
        return ResponseEntity.ok(ApiResponse.success("Login successful", response));
    }
}
