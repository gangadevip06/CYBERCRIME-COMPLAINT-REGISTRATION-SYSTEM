package com.cybercrime.controller;

import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.IOException;

/**
 * WebController — serves the SPA frontend for all non-API routes
 */
@Controller
public class WebController {

    @GetMapping({"/", "/login", "/register",
                 "/user/dashboard", "/admin/dashboard", "/officer/dashboard"})
    public void index(HttpServletResponse response) throws IOException {
        response.sendRedirect("/index.html");
    }
}
