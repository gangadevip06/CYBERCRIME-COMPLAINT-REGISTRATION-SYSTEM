package com.cybercrime.config;

import com.cybercrime.model.Admin;
import com.cybercrime.repository.AdminRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * DataInitializer — Seeds the database with a default admin on first run.
 * Runs automatically on startup via CommandLineRunner.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DataInitializer.class);

    @Autowired private AdminRepository adminRepository;
    @Autowired private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        // Create default admin if none exists
        if (adminRepository.count() == 0) {
            Admin admin = new Admin(
                "System Administrator",
                "admin@cybercrime.gov.in",
                passwordEncoder.encode("Admin@1234"),
                "CCRS-ADMIN-001"
            );
            admin.setDepartment("Cyber Crime Investigation Division");
            adminRepository.save(admin);

            logger.info("=================================================");
            logger.info("  DEFAULT ADMIN CREATED");
            logger.info("  Email   : admin@cybercrime.gov.in");
            logger.info("  Password: Admin@1234");
            logger.info("  Code    : CCRS-ADMIN-001");
            logger.info("=================================================");
        }
    }
}
