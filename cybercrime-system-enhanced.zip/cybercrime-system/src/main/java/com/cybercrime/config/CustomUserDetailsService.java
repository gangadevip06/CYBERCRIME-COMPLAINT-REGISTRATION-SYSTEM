package com.cybercrime.config;

import com.cybercrime.repository.AdminRepository;
import com.cybercrime.repository.PoliceOfficerRepository;
import com.cybercrime.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;

import java.util.Collections;

/**
 * CustomUserDetailsService — Loads user details from DB for Spring Security
 * Checks all three user tables: users, admins, police_officers
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired private UserRepository userRepository;
    @Autowired private AdminRepository adminRepository;
    @Autowired private PoliceOfficerRepository officerRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        // Check users table
        var user = userRepository.findByEmail(email);
        if (user.isPresent()) {
            var u = user.get();
            return new org.springframework.security.core.userdetails.User(
                    u.getEmail(), u.getPassword(),
                    Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")));
        }

        // Check admins table
        var admin = adminRepository.findByEmail(email);
        if (admin.isPresent()) {
            var a = admin.get();
            return new org.springframework.security.core.userdetails.User(
                    a.getEmail(), a.getPassword(),
                    Collections.singletonList(new SimpleGrantedAuthority("ROLE_ADMIN")));
        }

        // Check police officers table
        var officer = officerRepository.findByEmail(email);
        if (officer.isPresent()) {
            var o = officer.get();
            return new org.springframework.security.core.userdetails.User(
                    o.getEmail(), o.getPassword(),
                    Collections.singletonList(new SimpleGrantedAuthority("ROLE_POLICE_OFFICER")));
        }

        throw new UsernameNotFoundException("User not found with email: " + email);
    }
}
