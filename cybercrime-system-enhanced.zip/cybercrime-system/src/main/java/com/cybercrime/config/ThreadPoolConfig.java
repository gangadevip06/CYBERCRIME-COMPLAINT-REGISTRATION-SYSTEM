package com.cybercrime.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * ThreadPoolConfig — CO3: Multithreading configuration
 * Configures thread pools for:
 *   1. File processing (evidence uploads run in background)
 *   2. Notification processing (async complaint notifications)
 */
@Configuration
public class ThreadPoolConfig {

    /**
     * Executor for file upload processing — CO3: Multithreading
     * Handles multiple simultaneous evidence file uploads
     * without blocking the HTTP request thread.
     */
    @Bean(name = "fileProcessingExecutor")
    public Executor fileProcessingExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);        // 4 base threads
        executor.setMaxPoolSize(10);        // Scale up to 10 for high load
        executor.setQueueCapacity(50);      // Queue up to 50 tasks
        executor.setThreadNamePrefix("FileUpload-");
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.setAwaitTerminationSeconds(30);
        executor.initialize();
        return executor;
    }

    /**
     * Executor for background report generation and notifications
     * CO3: Separate thread pool prevents I/O tasks from blocking main threads
     */
    @Bean(name = "backgroundTaskExecutor")
    public Executor backgroundTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(5);
        executor.setQueueCapacity(25);
        executor.setThreadNamePrefix("BgTask-");
        executor.initialize();
        return executor;
    }
}
