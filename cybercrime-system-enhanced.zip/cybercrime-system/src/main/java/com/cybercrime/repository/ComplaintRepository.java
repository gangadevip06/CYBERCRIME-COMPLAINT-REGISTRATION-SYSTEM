package com.cybercrime.repository;

import com.cybercrime.model.Complaint;
import com.cybercrime.model.PoliceOfficer;
import com.cybercrime.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ComplaintRepository extends JpaRepository<Complaint, Long> {

    Optional<Complaint> findByComplaintId(String complaintId);
    List<Complaint> findByFiledBy(User user);
    List<Complaint> findByAssignedOfficer(PoliceOfficer officer);
    List<Complaint> findBySolved(boolean solved);
    List<Complaint> findByStatus(Complaint.ComplaintStatus status);
    List<Complaint> findByCrimeType(Complaint.CrimeType crimeType);

    @Query("SELECT c FROM Complaint c WHERE " +
           "LOWER(c.complaintId) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.title) LIKE LOWER(CONCAT('%', :keyword, '%'))")
    List<Complaint> searchComplaints(@Param("keyword") String keyword);

    @Query("SELECT c FROM Complaint c WHERE c.filedAt >= :fromDate ORDER BY c.filedAt DESC")
    List<Complaint> findByFiledAtAfter(@Param("fromDate") LocalDateTime fromDate);

    @Query("SELECT c FROM Complaint c WHERE c.filedAt BETWEEN :start AND :end ORDER BY c.filedAt DESC")
    List<Complaint> findByDateRange(@Param("start") LocalDateTime start,
                                    @Param("end") LocalDateTime end);

    List<Complaint> findByAssignedOfficerAndStatus(PoliceOfficer officer,
                                                    Complaint.ComplaintStatus status);

    @Query("SELECT c FROM Complaint c WHERE c.assignedOfficer = :officer AND c.filedAt >= :fromDate")
    List<Complaint> findByOfficerAndDateRange(@Param("officer") PoliceOfficer officer,
                                               @Param("fromDate") LocalDateTime fromDate);

    long countBySolved(boolean solved);
    long countByStatus(Complaint.ComplaintStatus status);
    long countByCrimeType(Complaint.CrimeType crimeType);

    List<Complaint> findByAssignedOfficerAndSolved(PoliceOfficer officer, boolean solved);

    @Query("SELECT c FROM Complaint c WHERE c.solved = true AND " +
           "(LOWER(c.title) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.description) LIKE LOWER(CONCAT('%', :keyword, '%')) OR " +
           "LOWER(c.caseResolutionNotes) LIKE LOWER(CONCAT('%', :keyword, '%')))")
    List<Complaint> searchSolvedCases(@Param("keyword") String keyword);

    @Query("SELECT c FROM Complaint c WHERE c.solved = true AND c.crimeType = :crimeType")
    List<Complaint> findSolvedByCrimeType(@Param("crimeType") Complaint.CrimeType crimeType);
}
