package com.cybercrime.repository;

import com.cybercrime.model.Complaint;
import com.cybercrime.model.Evidence;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface EvidenceRepository extends JpaRepository<Evidence, Long> {
    List<Evidence> findByComplaint(Complaint complaint);
    Optional<Evidence> findByStoredFileName(String storedFileName);
    List<Evidence> findByEvidenceType(Evidence.EvidenceType evidenceType);
}
