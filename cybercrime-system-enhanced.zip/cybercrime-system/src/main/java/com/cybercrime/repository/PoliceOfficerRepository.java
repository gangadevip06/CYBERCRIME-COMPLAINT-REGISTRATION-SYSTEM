package com.cybercrime.repository;

import com.cybercrime.model.PoliceOfficer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface PoliceOfficerRepository extends JpaRepository<PoliceOfficer, Long> {
    Optional<PoliceOfficer> findByEmail(String email);
    Optional<PoliceOfficer> findByBadgeNumber(String badgeNumber);
    boolean existsByEmail(String email);
    boolean existsByBadgeNumber(String badgeNumber);
    List<PoliceOfficer> findByActiveTrue();
    List<PoliceOfficer> findByStation(String station);
}
