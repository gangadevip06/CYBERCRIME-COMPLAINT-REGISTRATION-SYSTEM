package com.cybercrime;

import com.cybercrime.util.ComplaintIdGenerator;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for Cybercrime Complaint System
 */
@SpringBootTest
class CybercrimeComplaintSystemApplicationTests {

    @Autowired
    private ComplaintIdGenerator idGenerator;

    @Test
    void contextLoads() {
        assertNotNull(idGenerator);
    }

    @Test
    void complaintIdGeneratorProducesUniqueIds() {
        String id1 = idGenerator.generate();
        String id2 = idGenerator.generate();
        assertNotNull(id1);
        assertNotNull(id2);
        assertNotEquals(id1, id2);
        assertTrue(id1.startsWith("CC-"));
        System.out.println("Generated IDs: " + id1 + ", " + id2);
    }

    @Test
    void complaintIdHasCorrectFormat() {
        String id = idGenerator.generate();
        // Format: CC-YYYY-XXXXXXXXXXXXXXXX
        assertTrue(id.startsWith("CC-2"));
        String[] parts = id.split("-");
        assertEquals(3, parts.length);
        assertEquals("CC", parts[0]);
        assertEquals(4, parts[1].length()); // year
    }
}
